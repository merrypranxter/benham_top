// Sector geometry and arc width calculation
