// Subjective color prediction by arc parameters
