// TODO: strobe.frag
