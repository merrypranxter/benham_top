// Benham top renderer and rotation control
