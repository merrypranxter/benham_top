// TODO: disk.vert
